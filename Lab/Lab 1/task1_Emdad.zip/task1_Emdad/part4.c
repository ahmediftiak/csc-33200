// Name: Md Shahid Emdad
// EMPL ID: 23726181
// Email: semdad000@citymail.cuny.edu

/*
Problem:

Task 1, part 4: Repeat part 2 (by writing a new C program) as per the following procedure:

(a) Read the next 100 characters from source.txt, and among characters read, replace
each character `1` with character `L` and all characters are then written in
destination.txt

(b) Write characters "XYZ" into file destination.txt

(c) Repeat the previous steps until the end of file source.txt. The last read step may not
have 100 characters. 
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int findFile;
    int findFile2;
    errno = 0;
    // Open source.txt file -> read mode only
    findFile = open(argv[1], O_RDONLY);

    // Open destination.txt file in write mode or create if it doesn't exist
    findFile2 = open("destination.txt", O_WRONLY | O_CREAT);

    // Print errors if it failed to open
    if (findFile < 0 || findFile2 < 0)
    {
        printf("Failed to open");
        perror("open \n");
        return 1;
    }
    else
    {
        int counter;
        int limit = 100;
        char buffer[limit];

        while ((counter = read(findFile, buffer, limit)) != 0)
        {
            // Error message if failed to read
            if (counter < 0)
            {
                printf("Failed to read");
                perror("read \n");
                return 1;
            }

            // Otherwise, replace every '1' character with  'L' character
            for (int i = 0; i < limit; i++)
            {
                if (buffer[i] == '1')
                {
                    buffer[i] = 'L';
                }
            }

            // Then, write to destination.txt
            counter = write(findFile2, buffer, counter);
            counter = write(findFile2, "XYZ", 3);

            // Error message if failed to write
            if (counter < 0)
            {
                printf("Failed to write");
                perror("write \n");
                return 1;
            }
        }
        // Print to console once copying and replacing has been done succesfully
        printf("\nWritten to file succesfully");
    }

    // Close file and error with close system call
    if (close(findFile) < 0 || close(findFile2) < 0)
    {
        printf("Failed to close");
        perror("close \n");
        return 1;
    }
    else
    {
        printf("\nClosed Succesfully\n\n");
    }

    return 0;
}