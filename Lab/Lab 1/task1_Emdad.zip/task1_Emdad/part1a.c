// Name: Md Shahid Emdad
// EMPL ID: 23726181
// Email: semdad000@citymail.cuny.edu

// Problem: Extend code snippet 1 to check for read and
// write access permissions of a given file

//(given code - snippet 1)

#include <stdio.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char *argv[])
{
  char *filepath = argv[1];
  int returnval;

  // Check file existence
  returnval = access(filepath, F_OK);
  if (returnval == 0)
    printf("\n %s exists.\n", filepath);
  else
  {
    if (errno == ENOENT)
      printf("%s does not exist.\n", filepath);
    else if (errno == EACCES)
      printf("%s is not accessible.\n", filepath);
    return 0;
  }

  // Check read access
  returnval = access(filepath, R_OK);
  if (returnval == 0)
    printf("\n %s can read.\n", filepath);
  else
  {
    if (errno == ENOENT)
      printf("%s does not exist.\n", filepath);
    else if (errno == EACCES)
      printf("%s is not accessible.\n", filepath);
    return 0;
  }

  // Check write access
  returnval = access(filepath, W_OK);
  if (returnval == 0)
    printf("\n %s can write.\n", filepath);
  else
  {
    if (errno == ENOENT)
      printf("%s does not exist.\n", filepath);
    else if (errno == EACCES)
      printf("%s is not accessible.\n \n", filepath);
    return 0;
  }
  return 0;
}