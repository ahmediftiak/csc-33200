// Name: Md Shahid Emdad
// EMPL ID: 23726181
// Email: semdad000@citymail.cuny.edu

// Problem: Write a C program to implement a command called displaycontent that 
// takes a (text) file name as argument and display its contents.

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int findFile;
    errno = 0;
    // Open file in read only
    findFile = open(argv[1], O_RDONLY);

    // Print errors if failed to open as requested
    if (findFile == -1)
    {
        printf("Failed to open");
        perror("open");
        return 1;
    }
    else
    {
        // Print content to console

        printf("\n"); // For better text readability
        off_t line = lseek(findFile, 0, SEEK_END);

        if (line < 0)
            return 1;

        char buffer[line];

        lseek(findFile, 0, SEEK_SET);
        ssize_t bytes = read(findFile, buffer, sizeof(buffer));

        // For error with read system call
        if (bytes < 0)
        {
            printf("Failed to read");
            perror("read \n");
            return 1;
        }
        // Error with write system call
        if (write(1, buffer, bytes) < 0)
        {
            printf("Failed to write");
            perror("write \n");
            return 1;
        }
    }

    // Close file and print error -> failed to close
    if (close(findFile) < 0)
    {
        printf("Failed to close");
        perror("close \n");
        return 1;
    }
    else
    {
        printf("\n\nClosed Succesfully\n");
    }
    return 0;
}