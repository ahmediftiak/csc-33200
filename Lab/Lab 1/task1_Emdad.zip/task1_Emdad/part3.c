// Name: Md Shahid Emdad
// EMPL ID: 23726181
// Email: semdad000@citymail.cuny.edu

// Problem: Write a C program that mimics the cp command using open() system call
// to open source.txt file in read-only mode and copy the contents of it to
// destination.txt using read() and write() system calls.

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[])
{

    // check if there are enough arguments for cp
    if (argc != 3)
    {
        printf("\nError: provide source and destination files!\n\n");
        return -1;
    }

    int findFile;
    int findFile2;
    errno = 0;
    // Open file read mode only
    findFile = open(argv[1], O_RDONLY);

    // Open file in write mode or create -> it doesn't exist
    findFile2 = open(argv[2], O_WRONLY | O_CREAT, 00700);

    // Print errors -> failed to open
    if (findFile < 0 || findFile2 < 0)
    {
        printf("Failed to open");
        perror("open\n");
        return 1;
    }
    else
    {
        // Print contents of source.txt to destination.txt
        printf("\n");
        off_t l = lseek(findFile, 0, SEEK_END);
        if (l < 0)
            return 1;
        char buffer[l];
        lseek(findFile, 0, SEEK_SET);
        ssize_t bytes = read(findFile, buffer, sizeof(buffer));

        // ?error -> read system call
        if (bytes < 0)
        {
            printf("Failed to read");
            perror("read \n");
            return 1;
        }

        // Write to destination.txt and error with write system call
        if (write(findFile2, buffer, bytes) < 0)
        {
            printf("Failed to write");
            perror("write \n");
            return 1;
        }
        else
        {
            printf("Copied Succesfully");
        }
    }

    // close file and give error check with close system call
    if (close(findFile) < 0 || close(findFile2) < 0)
    {
        printf("Failed to close");
        perror("close \n");
        return 1;
    }
    else
    {
        printf("\nClosed Succesfully\n\n");
    }

    return 0;
}