// Problem: Write a C program where open system call creates a new file (say, destination.txt) and
// then opens it. (Hint: use the bitwise OR flag)

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int findFile;
    errno = 0;
    // Open the file with bitwise OR flag (read only)
    findFile = open("destination.txt", O_RDONLY | O_CREAT);

    // Print errors if it failed to open
    if (findFile < 0)
    {
        printf("Open Failed");
        perror("Open");
        return 1;
    }
    else
    {
        printf("\nSuccessful Opened\n");
    }

    // Close file and print error if failed to close
    if (close(findFile) < 0)
    {
        printf("Close Failed");
        perror("Close\n");
        return 1;
    }
    else
    {
        printf("Succesfully Closed\n\n");
    }
    return 0;
}